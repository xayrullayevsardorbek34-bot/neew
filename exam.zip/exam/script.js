let a = document.getElementsByClassName('first')
let b = document.getElementsByClassName('second')
let c = document.getElementsByClassName('third')
let d = document.querySelector('div')
let h1 = document.querySelector('h1')
let myfunction = () =>{
     d.style.background = 'black';
}

let myfunction2 = () => d.style.background = "red";



// h1.textContent = Math.random(100)
let function1 = () =>{
    h1.textContent = Math.round(Math.random() * 100);
}

// .Math.round
